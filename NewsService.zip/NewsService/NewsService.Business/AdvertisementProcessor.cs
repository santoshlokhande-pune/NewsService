﻿using NewsService.Data.Business;
using NewsService.Data.Constants;
using NewsService.Data.Entity;
using System;
using System.Collections.Generic;
using System.Linq;

namespace NewsService.Business
{
    public class AdvertisementProcessor : IAdvertisementProcessor
    {
        private readonly int pageCount;
        private List<NewsSource> newsSources;
        private List<Advertisement> advertisements;
        public AdvertisementProcessor(int pageCount)
        {
            this.pageCount = pageCount;
        }

        /// <summary>
        /// This function will add the ads to each page depending on the high priority news
        /// </summary>
        /// <param name="newsSources"></param>
        /// <param name="advertisements"></param>
        /// <returns></returns>
        public List<NewsSource> AddAdvertisementsToNews(List<NewsSource> newsSources, List<Advertisement> advertisements, bool needConcatedResult)
        {
            this.newsSources = newsSources;
            this.advertisements = advertisements;
            if (!needConcatedResult)
            {
                foreach (NewsSource newsSource in newsSources)
                {
                    ApplyAdvertisementRules(newsSource);
                }
                return this.newsSources;
            }
            else
            {
                NewsSource combinedNewSource = new NewsSource(NewsSources.All, false);
                this.newsSources = newsSources;

                foreach (NewsSource newsSource in newsSources)
                {
                    combinedNewSource.News = (combinedNewSource.News == null ? newsSource.News : combinedNewSource.News.Concat(newsSource.News));
                }

                ApplyAdvertisementRules(combinedNewSource);
                return new List<NewsSource>
                {
                    combinedNewSource
                };
            }
        }

        private void ApplyAdvertisementRules(NewsSource newsSource)
        {
            newsSource.NewsPages = new List<(int PageNumber, IEnumerable<NewsDetails> NewsDetails, IEnumerable<Advertisement> Advertisements)>();
            IEnumerable<NewsDetails> news = newsSource.News.OrderBy(t => t.Priority).AsEnumerable();
            int extraNews = newsSource.News.Count() % (ApplicationConstants.NEWS_PAGE_SIZE - ApplicationConstants.ADVERTISEMENT_COUNT_IN_SINGLE_PAGE);
            int totalNumberOfPages = newsSource.News.Count() / (ApplicationConstants.NEWS_PAGE_SIZE - ApplicationConstants.ADVERTISEMENT_COUNT_IN_SINGLE_PAGE);

            if (extraNews > 0)
                totalNumberOfPages++;

            int currentPageNumber = 1;
            while (currentPageNumber <= (totalNumberOfPages < pageCount ? totalNumberOfPages : pageCount) && news.Count() > 0)
            {
                IEnumerable<NewsDetails> topXNews = news.Take(ApplicationConstants.NEWS_PAGE_SIZE);
                int totalHighPriorityNewsInX = topXNews.Count(t => t.Priority == NewsPriority.High);
                var advCount = 0;
                var newsCount = ApplicationConstants.NEWS_PAGE_SIZE;

                if (totalHighPriorityNewsInX == ApplicationConstants.NEWS_PAGE_SIZE)
                {
                    advCount = 0;
                }
                else if (totalHighPriorityNewsInX == (ApplicationConstants.NEWS_PAGE_SIZE - 1))
                {
                    advCount = 1;
                }
                else
                {
                    advCount = ApplicationConstants.ADVERTISEMENT_COUNT_IN_SINGLE_PAGE;
                }

                newsCount = ApplicationConstants.NEWS_PAGE_SIZE - advCount;
                newsSource.NewsPages.Add((PageNumber: currentPageNumber, NewsDetails: topXNews.Take(newsCount), Advertisements: advertisements.Take(advCount)));
                news = news.Skip(newsCount);
                currentPageNumber++;
            }
        }
    }
}
