﻿using NewsService.Data.Business;
using NewsService.Data.Constants;
using NewsService.Data.Entity;
using NewsService.Data.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NewsService.Business
{
    public class NewsProcessorService : INewsProcessor
    {
        List<INewsService> newsServices = new List<INewsService>();
        List<NewsSource> newsSources = new List<NewsSource>();
        List<Advertisement> advertisements = new List<Advertisement>();
        private readonly INewsSourceService newsSourceService;
        private readonly IAdvertisementService advertisementService;
        private readonly IAdvertisementProcessor advertisementProcessor;

        public NewsProcessorService(INewsSourceService newsSourceService, IAdvertisementService advertisementService, IAdvertisementProcessor advertisementProcessor)
        {
            this.newsSourceService = newsSourceService;
            this.advertisementService = advertisementService;
            this.advertisementProcessor = advertisementProcessor;
        }

        /// <summary>
        /// Get all the news from news resources.
        /// Get the advertisements
        /// Add advertisements the news pages as per the business rule.
        /// </summary>
        /// <param name="newsSelectionCriteria"></param>
        /// <returns></returns>
        public async Task<List<NewsSource>> ProcessNewsAsync(NewsSelectionCriteria newsSelectionCriteria)
        {
            await GetNewsAsync(newsSelectionCriteria);
            await GetAdvertisementsAsync();
            AddAdvertisementsToNews(newsSelectionCriteria.NeedConcatedResult);
            return newsSources;
        }


        /// <summary>
        /// Get the news from all the provided news services.
        /// </summary>
        /// <returns></returns>
        private async Task<bool> GetNewsAsync(NewsSelectionCriteria newsSelectionCriteria)
        {
            //Reading from cache.
            if (!MemoryCacheService.GetObject(ApplicationConstants.CACHE_KEY_NEWS_SERVICES, out newsServices))
            {
                newsServices = await newsSourceService.GetNewsServicesAsync();
                MemoryCacheService.SetObject(ApplicationConstants.CACHE_KEY_NEWS_SERVICES, newsServices);
            }

            foreach (INewsService service in newsServices)
            {
                NewsSource newsSource = new NewsSource(service.Name, service.IsInternal)
                {
                    News = await service.GetNewsAsync(newsSelectionCriteria)
                };

                newsSources.Add(newsSource);
            }
            return true;
        }

        private async Task<bool> GetAdvertisementsAsync()
        {
            advertisements = await advertisementService.GetAdvertisementAsync();
            return true;
        }

        private void AddAdvertisementsToNews(bool needConcatedResult)
        {
            newsSources = advertisementProcessor.AddAdvertisementsToNews(newsSources, advertisements, needConcatedResult);
        }
    }
}
