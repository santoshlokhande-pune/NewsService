﻿using Microsoft.Extensions.Caching.Memory;
using NewsService.Data.Constants;
using System;

namespace NewsService.Business
{
    //Singleton design pattern
    //Caching to improve performance
    public static class MemoryCacheService
    {
        public static MemoryCache Cache { get; set; }
        static MemoryCacheService()
        {
            Cache = new MemoryCache(new MemoryCacheOptions());
        }

        /// <summary>
        /// Get object from cache
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public static bool GetObject<T>(string key, out T value)
        {
            return Cache.TryGetValue(key, out value);
        }

        /// <summary>
        /// Add object to cache
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="key"></param>
        /// <param name="value"></param>
        /// <returns></returns>
        public static object SetObject<T>(string key, T value)
        {
            return Cache.Set(key, value, new MemoryCacheEntryOptions()
            {
                SlidingExpiration = TimeSpan.FromMinutes(ApplicationConstants.CACHE_TIME_OUT),
                AbsoluteExpirationRelativeToNow = TimeSpan.FromMinutes(ApplicationConstants.ABSOLUT_EXPRIRAION_TIMEOUT)
            });
        }

        /// <summary>
        /// Remove object from cache
        /// </summary>
        /// <param name="key"></param>
        /// <returns></returns>
        public static bool RemoveObjectByKey(string key)
        {
            Cache.Remove(key);
            return true;
        }
    }
}
