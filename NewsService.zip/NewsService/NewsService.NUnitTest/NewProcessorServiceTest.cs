using Moq;
using NewsService.Business;
using NewsService.Data.Business;
using NewsService.Data.Constants;
using NewsService.Data.Interfaces;
using NUnit.Framework;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using NewsService.Data.Entity;

namespace NewsService.NUnitTest
{
    [TestFixture]
    public class NewProcessorServiceTest
    {
        //More tests need to be added to test the scenario with multiple pages.
        //For now I have added tests for first page.
        private List<INewsService> newsServices = new List<INewsService>();
        private NewsSelectionCriteria newsSelectionCriteria = new NewsSelectionCriteria();

        [SetUp]
        public void Setup()
        {
            MemoryCacheService.RemoveObjectByKey(ApplicationConstants.CACHE_KEY_NEWS_SERVICES);
            newsServices = new List<INewsService>();
        }

        [Test]
        [TestCase(5, ExpectedResult = 1)]
        public int NewProcessorService_GetNewsServicesAsync_ValidateServicesCount(int pageCount)
        {
            SetupNewsForGoogle(6);
            INewsProcessor newProcessor = GetNewProcessorService(pageCount);
            var count = newProcessor.ProcessNewsAsync(newsSelectionCriteria).Result.Count;
            return count;
        }

        [Test]
        [TestCase(5, ExpectedResult = 4)]
        [TestCase(6, ExpectedResult = 4)]
        [TestCase(4, ExpectedResult = 4)]
        [TestCase(3, ExpectedResult = 3)]
        public int NewProcessorService_GetNewsServicesAsync_ValidateNewsPages(int pageCount)
        {
            SetupNewsForGoogle(6);
            INewsProcessor newProcessor = GetNewProcessorService(pageCount);
            return newProcessor.ProcessNewsAsync(newsSelectionCriteria).Result[0].NewsPages.Count;
        }

        [Test]
        [TestCase(5, ExpectedResult = 6)]
        // 6 news and 2 Advertisement
        public int NewProcessorService_GetNewsServicesAsync_Validate6NewsAnd2Advertisements(int pageCount)
        {
            SetupNewsForGoogle(6);
            INewsProcessor newProcessor = GetNewProcessorService(pageCount);
            return newProcessor.ProcessNewsAsync(newsSelectionCriteria).Result[0].NewsPages[0].NewsDetails.Count();
        }

        [Test]
        [TestCase(6, ExpectedResult = 2)]
        [TestCase(5, ExpectedResult = 2)]
        [TestCase(4, ExpectedResult = 2)]
        // 6 news and 2 Advertisement
        public int NewProcessorService_GetNewsServicesAsync_Validate2Advertisements(int pageCount)
        {
            SetupNewsForGoogle(6);
            INewsProcessor newProcessor = GetNewProcessorService(pageCount);
            return newProcessor.ProcessNewsAsync(newsSelectionCriteria).Result[0].NewsPages[0].Advertisements.Count();
        }

        [Test]
        [TestCase(5, 5, 6, 2, ExpectedResult = true)]
        // 5 high priority news and 2 Advertisement
        [TestCase(5, 6, 6, 2, ExpectedResult = true)]
        // 6 high priority news and 2 Advertisement
        [TestCase(5, 7, 7, 1, ExpectedResult = true)]
        // 7 high priority news and 1 Advertisement
        [TestCase(5, 8, 8, 0, ExpectedResult = true)]
        // 8 high priority news and 0 Advertisement
        [TestCase(5, 8, 8, 1, ExpectedResult = false)]
        // 8 high priority news and 0 Advertisement
        public bool NewProcessorService_GetNewsServicesAsync_ValidateAdvertisementsCount(int pageCount, int highNewsCount, int newsCount, int adsCount)
        {
            SetupNewsForGoogle(highNewsCount);
            INewsProcessor newProcessor = GetNewProcessorService(pageCount);

            return IsResultValid(newProcessor, newsCount, adsCount);
        }

        [Test]
        [TestCase(5, 2, 6, 2, ExpectedResult = true)]
        // 6 high priority news and 2 Advertisement
        [TestCase(5, 3, 8, 0, ExpectedResult = true)]
        // 9 high priority news and 2 Advertisement
        [TestCase(5, 4, 8, 0, ExpectedResult = true)]
        // 12 high priority news and 1 Advertisement
        public bool NewProcessorService_ConcatedResult_ValidateAdvertisementsCount(int pageCount, int highNewsCount, int newsCount, int adsCount)
        {
            newsSelectionCriteria.NeedConcatedResult = true;
            SetupNewsForMultipleServices(highNewsCount);
            INewsProcessor newProcessor = GetNewProcessorService(pageCount);

            return IsResultValid(newProcessor, newsCount, adsCount);
        }

        [Test]
        [TestCase(5, 0, 6, 2, ExpectedResult = true)]
        public bool NewProcessorService_ValidateNewsCountByCategory(int pageCount, int highNewsCount, int newsCount, int adsCount)
        {
            newsSelectionCriteria.NeedConcatedResult = true;
            newsSelectionCriteria.NewsCategory = NewsCategoryEnum.Business;

            SetupNewsForGoogle(highNewsCount, NewsCategoryEnum.Business.ToString());
            INewsProcessor newProcessor = GetNewProcessorService(pageCount);

            var newsPage = newProcessor.ProcessNewsAsync(newsSelectionCriteria).Result[0].NewsPages[0];
            var page1Result = ((newsCount == newsPage.NewsDetails.Count())
                    &&
                 (adsCount == newsPage.Advertisements.Count())
                    &&
                 //all news should be for Business category
                 (newsPage.NewsDetails.Count(t => t.Category == newsSelectionCriteria.NewsCategory.ToString()) == newsCount));

            return page1Result;
        }

        #region private methods

        /// <summary>
        /// Get the sample news with 'expectedHighPriorityNewsCount' high priority news
        /// </summary>
        /// <param name="expectedHighPriorityNewsCount">Number of high priority news in the list</param>
        private void SetupNewsForGoogle(int expectedHighPriorityNewsCount, string newsCategory = null)
        {
            newsServices.Add(GetNewsService(NewsSources.Google, expectedHighPriorityNewsCount, newsCategory).Object);
        }

        private void SetupNewsForMultipleServices(int expectedHighPriorityNewsCount)
        {
            newsServices.Add(GetNewsService(NewsSources.Google, expectedHighPriorityNewsCount).Object);
            newsServices.Add(GetNewsService(NewsSources.PTI, expectedHighPriorityNewsCount).Object);
            newsServices.Add(GetNewsService(NewsSources.Internal1, expectedHighPriorityNewsCount).Object);
        }

        private Mock<INewsService> GetNewsService(string serviceName, int expectedHighPriorityNewsCount, string newsCategory = null)
        {
            Mock<INewsService> moqNewsService = new Mock<INewsService>
            {
                Name = serviceName
            };

            if (newsCategory != null)
            {
                moqNewsService.Setup(t => t.GetNewsAsync(newsSelectionCriteria)).Returns(Task.FromResult(TestHelper.GetSampleNewsByCategory(20, newsCategory)));
            }
            else
            {
                moqNewsService.Setup(t => t.GetNewsAsync(newsSelectionCriteria)).Returns(Task.FromResult(TestHelper.GetSampleNews(20, expectedHighPriorityNewsCount)));
            }

            return moqNewsService;
        }

        private INewsProcessor GetNewProcessorService(int pageCount)
        {
            Mock<INewsSourceService> newsSourceService = new Mock<INewsSourceService>();
            Mock<IAdvertisementService> advertisementService = new Mock<IAdvertisementService>();
            newsSourceService.Setup(t => t.GetNewsServicesAsync()).Returns(Task.FromResult(newsServices));
            advertisementService.Setup(t => t.GetAdvertisementAsync()).Returns(Task.FromResult(TestHelper.GetSampleAdvertisements()));
            return new NewsProcessorService(newsSourceService.Object, advertisementService.Object, new AdvertisementProcessor(pageCount));
        }

        private bool IsResultValid(INewsProcessor newProcessor, int newsCount, int adsCount)
        {
            var newsPage = newProcessor.ProcessNewsAsync(newsSelectionCriteria).Result[0].NewsPages[0];
            var page1Result = ((newsCount == newsPage.NewsDetails.Count())
                &&
                 (adsCount == newsPage.Advertisements.Count()));

            return page1Result;
        }

        #endregion private methods
    }
}