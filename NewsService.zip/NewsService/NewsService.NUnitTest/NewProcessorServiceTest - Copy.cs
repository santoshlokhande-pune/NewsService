using Moq;
using NewsService.Business;
using NewsService.Data.Business;
using NewsService.Data.Constants;
using NewsService.Data.Entity;
using NewsService.Data.Interfaces;
using NewsService.Services.FactoryServices;
using NUnit.Framework;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Linq;
using System;

namespace NewsService.NUnitTest
{
    public class NewProcessorServiceTest
    {
        List<INewsService> newsServices = new List<INewsService>();

        [SetUp]
        public void Setup()
        {
            MemoryCacheService.RemoveObjectByKey(ApplicationConstants.CacheKey_NewsServices);
        }

        private void SetupNews(int expectedHighPriorityNewsCount)
        {
            newsServices = new List<INewsService>();
            Mock<INewsService> moqNewsService = new Mock<INewsService>();
            moqNewsService.Setup(t => t.GetNewsAsync()).Returns(Task.FromResult(TestHelper.GetSampleNews(20, expectedHighPriorityNewsCount)));
            newsServices.Add(moqNewsService.Object);
        }

        [Test]
        [TestCase(5, ExpectedResult = 1)]
        public int NewProcessorService_GetNewsServicesasync_ValidateServicesCount(int pageCount)
        {
            SetupNews(6);
            Mock<INewsSourceService> newsSourceService = new Mock<INewsSourceService>();
            Mock<IAdvertisementService> advertisementService = new Mock<IAdvertisementService>();
            newsSourceService.Setup(t => t.GetNewsServicesAsync()).Returns(Task.FromResult(newsServices));
            advertisementService.Setup(t => t.GetAdvertisementAsync(It.IsAny<int>())).Returns(Task.FromResult(TestHelper.GetSampleAdvertisements()));
            INewProcessor newProcessor = new NewProcessorService(newsSourceService.Object, advertisementService.Object, new AdvertisementProcessorService(pageCount));
            var count = newProcessor.ProcessNewsAsync().Result.Count;
            return count;
        }

        [Test]
        [TestCase(5, ExpectedResult = 4)]
        [TestCase(6, ExpectedResult = 4)]
        [TestCase(4, ExpectedResult = 4)]
        [TestCase(3, ExpectedResult = 3)]
        public int NewProcessorService_GetNewsServicesasync_ValidateNewsPages(int pageCount)
        {
            SetupNews(6);
            Mock<INewsSourceService> newsSourceService = new Mock<INewsSourceService>();
            Mock<IAdvertisementService> advertisementService = new Mock<IAdvertisementService>();
            newsSourceService.Setup(t => t.GetNewsServicesAsync()).Returns(Task.FromResult(newsServices));
            advertisementService.Setup(t => t.GetAdvertisementAsync(It.IsAny<int>())).Returns(Task.FromResult(TestHelper.GetSampleAdvertisements()));
            INewProcessor newProcessor = new NewProcessorService(newsSourceService.Object, advertisementService.Object, new AdvertisementProcessorService(pageCount));
            var result = newProcessor.ProcessNewsAsync().Result[0].NewsPages.Count;
            return result;
        }

        [Test]
        [TestCase(5, ExpectedResult = 6)]
        // 6 news and 2 Advertisement
        public int NewProcessorService_GetNewsServicesasync_Validate6NewsAnd2Advertisements(int pageCount)
        {
            SetupNews(6);
            Mock<INewsSourceService> newsSourceService = new Mock<INewsSourceService>();
            Mock<IAdvertisementService> advertisementService = new Mock<IAdvertisementService>();
            newsSourceService.Setup(t => t.GetNewsServicesAsync()).Returns(Task.FromResult(newsServices));
            advertisementService.Setup(t => t.GetAdvertisementAsync(It.IsAny<int>())).Returns(Task.FromResult(TestHelper.GetSampleAdvertisements()));
            INewProcessor newProcessor = GetNewProcessorService();// new NewProcessorService(newsSourceService.Object, advertisementService.Object, new AdvertisementProcessorService(pageCount));
            var newsCount = newProcessor.ProcessNewsAsync().Result[0].NewsPages[0].NewsDetails.Count();
            return newsCount;
        }

        private INewProcessor GetNewProcessorService()
        {
            Mock<INewsSourceService> newsSourceService = new Mock<INewsSourceService>();
            Mock<IAdvertisementService> advertisementService = new Mock<IAdvertisementService>();
            newsSourceService.Setup(t => t.GetNewsServicesAsync()).Returns(Task.FromResult(newsServices));
            advertisementService.Setup(t => t.GetAdvertisementAsync(It.IsAny<int>())).Returns(Task.FromResult(TestHelper.GetSampleAdvertisements()));
            return new NewProcessorService(newsSourceService.Object, advertisementService.Object, new AdvertisementProcessorService(pageCount));
        }

        [Test]
        [TestCase(6, ExpectedResult = 2)]
        [TestCase(5, ExpectedResult = 2)]
        [TestCase(4, ExpectedResult = 2)]
        // 6 news and 2 Advertisement
        public int NewProcessorService_GetNewsServicesasync_Validate2Advertisements(int pageCount)
        {
            SetupNews(6);
            Mock<INewsSourceService> newsSourceService = new Mock<INewsSourceService>();
            Mock<IAdvertisementService> advertisementService = new Mock<IAdvertisementService>();
            newsSourceService.Setup(t => t.GetNewsServicesAsync()).Returns(Task.FromResult(newsServices));
            advertisementService.Setup(t => t.GetAdvertisementAsync(It.IsAny<int>())).Returns(Task.FromResult(TestHelper.GetSampleAdvertisements()));
            INewProcessor newProcessor = new NewProcessorService(newsSourceService.Object, advertisementService.Object, new AdvertisementProcessorService(pageCount));
            var newsCount = newProcessor.ProcessNewsAsync().Result[0].NewsPages[0].Advertisements.Count();
            return newsCount;
        }

        [Test]
        [TestCase(5, 5, 6, 2, ExpectedResult = true)]
        // 5 high priority news and 2 Advertisement
        [TestCase(5, 6, 6, 2, ExpectedResult = true)]
        // 6 high priority news and 2 Advertisement
        [TestCase(5, 7, 7, 1, ExpectedResult = true)]
        // 7 high priority news and 1 Advertisement
        [TestCase(5, 8, 8, 0, ExpectedResult = true)]
        // 8 high priority news and 0 Advertisement
        [TestCase(5, 8, 8, 1, ExpectedResult = false)]
        // 8 high priority news and 0 Advertisement
        public bool NewProcessorService_GetNewsServicesasync_ValidateAdvertisementsCount(int pageCount, int expectedHighPriorityNewsCount, int expectedNewsCount, int expectedAdvertisementsCount)
        {
            SetupNews(expectedHighPriorityNewsCount);
            Mock<INewsSourceService> newsSourceService = new Mock<INewsSourceService>();
            Mock<IAdvertisementService> advertisementService = new Mock<IAdvertisementService>();
            newsSourceService.Setup(t => t.GetNewsServicesAsync()).Returns(Task.FromResult(newsServices));
            advertisementService.Setup(t => t.GetAdvertisementAsync(It.IsAny<int>())).Returns(Task.FromResult(TestHelper.GetSampleAdvertisements()));
            INewProcessor newProcessor = new NewProcessorService(newsSourceService.Object, advertisementService.Object, new AdvertisementProcessorService(pageCount));
            return ((expectedNewsCount == newProcessor.ProcessNewsAsync().Result[0].NewsPages[0].NewsDetails.Count())
                &&
                 (expectedAdvertisementsCount == newProcessor.ProcessNewsAsync().Result[0].NewsPages[0].Advertisements.Count()));
        }
    }
}