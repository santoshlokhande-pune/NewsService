﻿using NewsService.Data.Constants;
using NewsService.Data.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace NewsService.NUnitTest
{
    public static class TestHelper
    {
        /// <summary>
        /// Get sample news.
        /// </summary>
        /// <param name="totalNews">Number of total news</param>
        /// <param name="expectedHighPriorityNewsCount">Number of high priority news</param>
        /// <returns>List<NewsDetails></returns>
        public static List<NewsDetails> GetSampleNews(int totalNews, int expectedHighPriorityNewsCount)
        {
            List<NewsDetails> list = new List<NewsDetails>();

            for (int count = 1; count <= expectedHighPriorityNewsCount; count++)
            {
                list.Add(new NewsDetails()
                {
                    Id = Guid.NewGuid(),
                    Author = "Test T",
                    Category = NewsCategoryEnum.Business.ToString(),
                    ShortDescription = string.Concat("This is the High priority news.", count),
                    LongDescription = string.Concat("This is the High priority news.", count),
                    Priority = Data.Constants.NewsPriority.High,
                    PublishDate = DateTime.UtcNow,
                    Title = "This is the test business news " + count
                });
            }

            for (int count = 1; count <= totalNews - (expectedHighPriorityNewsCount); count++)
            {
                list.Add(new NewsDetails()
                {
                    Id = Guid.NewGuid(),
                    Author = "Test T",
                    Category = NewsCategoryEnum.Political.ToString(),
                    ShortDescription = string.Concat("This is the test business news.", count),
                    LongDescription = string.Concat("This is the test business news.", count),
                    Priority = Data.Constants.NewsPriority.Medium,
                    PublishDate = DateTime.UtcNow,
                    Title = "This is the test business news " + count
                });
            }

            return list;
        }

        /// <summary>
        /// Get sample news.
        /// </summary>
        /// <param name="totalNews">Number of total news</param>
        /// <param name="category">News category</param>
        /// <returns>List<NewsDetails></returns>
        public static List<NewsDetails> GetSampleNewsByCategory(int totalNews, string category)
        {
            List<NewsDetails> list = new List<NewsDetails>();

            for (int count = 1; count <= totalNews; count++)
            {
                list.Add(new NewsDetails()
                {
                    Id = Guid.NewGuid(),
                    Author = "Test T",
                    Category = category,
                    ShortDescription = string.Concat("This is the news.", count),
                    LongDescription = string.Concat("This is the news.", count),
                    Priority = Data.Constants.NewsPriority.Medium,
                    PublishDate = DateTime.UtcNow,
                    Title = "This is the test business news " + count
                });
            }

            return list;
        }

        /// <summary>
        /// Get sample advertisements
        /// </summary>
        /// <returns>List<Advertisement></returns>
        public static List<Advertisement> GetSampleAdvertisements()
        {
            //If required we can add priority to the Advertisement so that high priority Advertisements can be shown on the top.
            List<Advertisement> list = new List<Advertisement>
            {
                new Advertisement()
                {
                    Id = Guid.NewGuid(),
                    Title = "Dell Optiplex 7070 Ultra - A PC like no other",
                    Description = "Dell Optiplex 7070 Ultra - A PC like no other",
                    ImageUrl = "https://static.clmbtech.com/ctn/549/images/10/66820657c27fc6e78028d202162a2829_1589952771892_0.webp",
                    TargetUrl = "https://www.delltechnologies.com/en-in/optiplex/index.htm?gacd=9860521-24158056-5855711-273310454-132500287&dgc=ba&dclid=CPXxhdaJx-kCFQRUjwodj7UOBQ"
                },

                new Advertisement()
                {
                    Id = Guid.NewGuid(),
                    Title = "Sample advertisement 2",
                    Description = "Sample advertisement 2",
                    ImageUrl = "https://static.clmbtech.com/ctn/549/images/10/66820657c27fc6e78028d202162a2829_1589952771892_0.webp",
                    TargetUrl = "https://www.delltechnologies.com/en-in/optiplex/index.htm?gacd=9860521-24158056-5855711-273310454-132500287&dgc=ba&dclid=CPXxhdaJx-kCFQRUjwodj7UOBQ"
                }
            };

            return list;
        }
    }
}
