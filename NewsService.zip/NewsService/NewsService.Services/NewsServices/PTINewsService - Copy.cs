﻿using NewsService.Data.AbstractClasses;
using NewsService.Data.Constants;
using NewsService.Data.Entity;
using NewsService.Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace NewsService.Services.NewsServices
{
    public class PTINewsService : NewsServiceBaseClass, INewsService
    {
        public PTINewsService( string name, bool isInternal)
        {
            Name = name;
            IsInternal = isInternal;
        }

        public async Task<List<NewsDetails>> GetNews()
        {
            //This should get the new from API of the news agency.
            return await (Task.Run(() => GetNewsFromSource()));
        }

        private List<NewsDetails> GetNewsFromSource()
        {
            List<NewsDetails> list = new List<NewsDetails>();
            list.Add(new NewsDetails()
            {
                Id = Guid.NewGuid(),
                Author = "Santosh L",
                Category = NewsCategoryEnum.Finance.ToString(),
                ShortDescription = "The Reserve Bank of India (RBI) slashed interest rates, extended moratorium on loan repayments and allowed banks to lend more to corporates in an effort to support the economy which is likely to contract for the first time in over four decades.",
                LongDescription = "The Reserve Bank of India (RBI) slashed interest rates, extended moratorium on loan repayments and allowed banks to lend more to corporates in an effort to support the economy which is likely to contract for the first time in over four decades.",
                Priority = Data.Constants.NewsPriority.High,
                PublishDate = DateTime.UtcNow,
                Title = "RBI ramps up economic support; cuts interest rates, extends loan moratorium"
            });

            list.Add(new NewsDetails()
            {
                Id = Guid.NewGuid(),
                Author = "Santosh L",
                Category = NewsCategoryEnum.Finance.ToString(),
                ShortDescription = "FinMin sanctions Rs 92,077 cr to states as devolution of central taxes",
                LongDescription = "FinMin sanctions Rs 92,077 cr to states as devolution of central taxes",
                Priority = Data.Constants.NewsPriority.High,
                PublishDate = DateTime.UtcNow,
                Title = "FinMin sanctions Rs 92,077 cr to states as devolution of central taxes"
            });

            list.Add(new NewsDetails()
            {
                Id = Guid.NewGuid(),
                Author = "Santosh L",
                Category = NewsCategoryEnum.Sports.ToString(),
                ShortDescription = "It has been described as New Zealand cricket''s darkest day, the 1955 Test against England when the Black Caps were skittled for just 26, a record low that still stands today.",
                LongDescription = "It has been described as New Zealand cricket''s darkest day, the 1955 Test against England when the Black Caps were skittled for just 26, a record low that still stands today.",
                Priority = Data.Constants.NewsPriority.Medium,
                PublishDate = DateTime.UtcNow,
                Title = "26 all out: the nightmare that still haunts New Zealand cricket",
            });

            list.Add(new NewsDetails()
            {
                Id = Guid.NewGuid(),
                Author = "Santosh L",
                Category = NewsCategoryEnum.Sports.ToString(),
                ShortDescription = " A Hollywood moment for NBA legend Kobe Bryant proved a big draw in a Beverly Hills auction of sport memorabilia, his handprints in concrete selling for 75,000.",
                LongDescription = " A Hollywood moment for NBA legend Kobe Bryant proved a big draw in a Beverly Hills auction of sport memorabilia, his handprints in concrete selling for 75,000.",
                Priority = Data.Constants.NewsPriority.Low,
                PublishDate = DateTime.UtcNow,
                Title = "Bryant items fetch premium prices, Trout card sets record"
            });

            list.Add(new NewsDetails()
            {
                Id = Guid.NewGuid(),
                Author = "Santosh L",
                Category = NewsCategoryEnum.Business.ToString(),
                ShortDescription = "Reliance Industries on Friday announced the sale of a 2.32 per cent stake in its digital unit to US private equity giant KKR for Rs 11,367 crore, the fifth deal in four weeks that will inject a combined Rs 78,562 crore in the oil-to-telecom conglomerate to help it pare debt.",
                LongDescription = "Reliance Industries on Friday announced the sale of a 2.32 per cent stake in its digital unit to US private equity giant KKR for Rs 11,367 crore, the fifth deal in four weeks that will inject a combined Rs 78,562 crore in the oil-to-telecom conglomerate to help it pare debt.",
                Priority = Data.Constants.NewsPriority.High,
                PublishDate = DateTime.UtcNow,
                Title = "Reliance strikes 5th deal, sells 2.32 pc in Jio Platforms for Rs 11,367 cr to KKR"
            });

            for (int count = 1; count <= 24; count++)
            {

                list.Add(new NewsDetails()
                {
                    Id = Guid.NewGuid(),
                    Author = "Test T",
                    Category = NewsCategoryEnum.Business.ToString(),
                    ShortDescription = "This is the test business news.",
                    LongDescription = "This is the test business news.",
                    Priority = Data.Constants.NewsPriority.Medium,
                    PublishDate = DateTime.UtcNow,
                    Title = "This is the test business news "
                });
            }

            return list;
        }
    }
}
