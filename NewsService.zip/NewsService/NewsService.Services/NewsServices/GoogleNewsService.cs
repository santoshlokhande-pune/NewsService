﻿using NewsService.Data.AbstractClasses;
using NewsService.Data.Constants;
using NewsService.Data.Entity;
using NewsService.Data.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NewsService.Services.NewsServices
{
    public class GoogleNewsService : NewsServiceBaseClass, INewsService
    {
        public GoogleNewsService()
        {
            Name = NewsSources.Google;
            IsInternal = false;
        }

        public async Task<List<NewsDetails>> GetNewsAsync(NewsSelectionCriteria newsSelectionCriteria)
        {
            //This should get the new from API of the news agency.
            return await (Task.Run(() => GetNewsFromSource(newsSelectionCriteria)));
        }
    }
}
