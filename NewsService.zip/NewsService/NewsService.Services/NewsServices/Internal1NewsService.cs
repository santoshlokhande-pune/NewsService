﻿using NewsService.Data.AbstractClasses;
using NewsService.Data.Constants;
using NewsService.Data.Entity;
using NewsService.Data.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NewsService.Services.NewsServices
{
    public class Internal1NewsService : NewsServiceBaseClass, INewsService
    {
        public Internal1NewsService()
        {
            Name = NewsSources.Internal1;
            IsInternal = true;
        }

        public async Task<List<NewsDetails>> GetNewsAsync(NewsSelectionCriteria newsSelectionCriteria)
        {
            //This should get the new from API of the news agency.
            return await Task.Run(() => GetNewsFromSource(newsSelectionCriteria));
        }
    }
}
