﻿using NewsService.Data.Entity;
using NewsService.Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;

namespace NewsService.Services.NewsServices
{
    public class NewsCategoryService : INewsCategoryService
    {
        public List<NewsCategory> GetNewsCategories()
        {
            return new List<NewsCategory>()
           {
                new NewsCategory() { Id = 1 , Name = "Political"  },
                new NewsCategory() { Id = 2 , Name = "Sports"  },
                new NewsCategory() { Id = 3 , Name = "Travel"  },
                new NewsCategory() { Id =4 , Name = "Advertisements"  }
           };
        }
    }
}
