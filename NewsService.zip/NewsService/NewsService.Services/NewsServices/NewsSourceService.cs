﻿using NewsService.Data.Constants;
using NewsService.Data.Interfaces;
using NewsService.Services.FactoryServices;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NewsService.Services.NewsServices
{
    public class NewsSourceService : INewsSourceService
    {
        /// <summary>
        /// Get the news services
        /// </summary>
        /// <returns></returns>
        public async Task<List<INewsService>> GetNewsServicesAsync()
        {
            //Just add new service and plug into the system.
            List<string> newsSources = new List<string>() { NewsSources.Google, NewsSources.PTI, NewsSources.Internal1 };
            //Code should be here to get the news sources from database.

            List<INewsService> newsServices = new List<INewsService>();
            foreach (string newsSource in newsSources)
            {
                INewsService newsService = await Task.Run(() => NewsSourceFactoryService.GetNewsSource(newsSource));
                newsServices.Add(newsService);
            }

            return newsServices;
        }
    }
}
