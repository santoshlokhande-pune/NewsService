﻿using NewsService.Data.Entity;
using NewsService.Data.Interfaces;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NewsService.Services.AdvertisementServices
{
    public class AdvertisementService : IAdvertisementService
    {
        public async Task<List<Advertisement>> GetAdvertisementAsync()
        {
            //We can add code to get the ads from external or internal source.
            return await Task.Run(() => GetAdvertisements());
        }

        private List<Advertisement> GetAdvertisements()
        {
            //If required we can add priority to the Advertisement so that high priority Advertisements can be shown on the top.
            return new List<Advertisement>();
        }
    }
}
