﻿using NewsService.Data.Constants;
using NewsService.Data.Entity;
using NewsService.Data.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace NewsService.Services.AdvertisementServices
{
    public class AdvertisementSourceService : IAdvertisementSourceService
    {
        public async Task<List<Advertisement>> GetAdvertisementSources()
        {
            //We can add code to get the ads from external or internal source.
            return await (Task.Run(() => GetSources()));
        }

        private List<Advertisement> GetAdvertisementSource()
        {
            //If required we can add priority to the Advertisement so that high priority Advertisements can be shown on the top.
            List<Advertisement> list = new List<Advertisement>();
            list.Add(new Advertisement()
            {
                Id = Guid.NewGuid(),
                Title = "Dell Optiplex 7070 Ultra - A PC like no other",
                Description = "Dell Optiplex 7070 Ultra - A PC like no other",
                ImageUrl = "https://static.clmbtech.com/ctn/549/images/10/66820657c27fc6e78028d202162a2829_1589952771892_0.webp",
                TargetUrl = "https://www.delltechnologies.com/en-in/optiplex/index.htm?gacd=9860521-24158056-5855711-273310454-132500287&dgc=ba&dclid=CPXxhdaJx-kCFQRUjwodj7UOBQ"
            });

            list.Add(new Advertisement()
            {
                Id = Guid.NewGuid(),
                Title = "Dell Optiplex 7070 Ultra - A PC like no other",
                Description = "Dell Optiplex 7070 Ultra - A PC like no other",
                ImageUrl = "https://static.clmbtech.com/ctn/549/images/10/66820657c27fc6e78028d202162a2829_1589952771892_0.webp",
                TargetUrl = "https://www.delltechnologies.com/en-in/optiplex/index.htm?gacd=9860521-24158056-5855711-273310454-132500287&dgc=ba&dclid=CPXxhdaJx-kCFQRUjwodj7UOBQ"
            });

            for (int count = 1; count <= take; count++)
            {
                list.Add(new Advertisement()
                {
                    Id = Guid.NewGuid(),
                    Title = String.Concat("Test Advertisement ", count),
                    Description = String.Concat("Test Advertisement Description", count),
                    ImageUrl = "https://static.clmbtech.com/ctn/549/images/10/66820657c27fc6e78028d202162a2829_1589952771892_0.webp",
                    TargetUrl = "https://www.delltechnologies.com/en-in/optiplex/index.htm?gacd=9860521-24158056-5855711-273310454-132500287&dgc=ba&dclid=CPXxhdaJx-kCFQRUjwodj7UOBQ"
                });
            }

            return list;
        }
    }
}
