﻿using NewsService.Data.Constants;
using NewsService.Data.Interfaces;
using NewsService.Services.NewsServices;

namespace NewsService.Services.FactoryServices
{
    public static class NewsSourceFactoryService
    {

        /// <summary>
        /// Factory method to get the news sources depending on its name
        /// </summary>
        /// <param name="sourceName"></param>
        /// <returns></returns>
        public static INewsService GetNewsSource(string sourceName)
        {
            //We can also use reflection to load the type depending on sourceName. We will require the type name as a input.
            switch (sourceName)
            {
                case NewsSources.Google: return new GoogleNewsService();
                case NewsSources.PTI: return new PTINewsService();
                case NewsSources.Internal1: return new Internal1NewsService();
                default: return null;
            }
        }
    }
}
