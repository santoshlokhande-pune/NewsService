﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NewsService.Data.Interfaces
{
    public interface INewsSourceService
    {
        /// <summary>
        /// Get the news services
        /// </summary>
        /// <returns></returns>
        Task<List<INewsService>> GetNewsServicesAsync();
    }
}
