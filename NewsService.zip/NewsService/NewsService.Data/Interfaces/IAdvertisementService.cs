﻿using NewsService.Data.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NewsService.Data.Interfaces
{
   public interface IAdvertisementService
    {
        Task<List<Advertisement>> GetAdvertisementAsync();
    }
}
