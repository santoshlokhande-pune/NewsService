﻿using NewsService.Data.Entity;
using System;
using System.Collections.Generic;
using System.Text;

namespace NewsService.Data.Interfaces
{
    public interface INewsCategoryService
    {
        List<NewsCategory> GetNewsCategories();
    }
}
