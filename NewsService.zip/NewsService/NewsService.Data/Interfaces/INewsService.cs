﻿using NewsService.Data.Entity;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NewsService.Data.Interfaces
{
    public interface INewsService
    {
        bool IsInternal { get; set; }

        string Name { get; set; }
        Task<List<NewsDetails>> GetNewsAsync(NewsSelectionCriteria newsSelectionCriteria);
    }
}
