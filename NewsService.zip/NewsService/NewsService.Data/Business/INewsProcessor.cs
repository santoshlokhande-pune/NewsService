﻿using NewsService.Data.Entity;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NewsService.Data.Business
{
    public interface INewsProcessor
    {
        /// <summary>
        /// Get all the news from news resources.
        /// Get the advertisements
        /// Add advertisements the news pages as per the business rule.
        /// </summary>
        /// <param name="newsSelectionCriteria"></param>
        /// <returns></returns>
        Task<List<NewsSource>> ProcessNewsAsync(NewsSelectionCriteria newsSelectionCriteria);
    }
}
