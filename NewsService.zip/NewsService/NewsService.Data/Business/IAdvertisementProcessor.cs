﻿using NewsService.Data.Entity;
using System.Collections.Generic;

namespace NewsService.Data.Business
{
    public interface IAdvertisementProcessor
    {
        /// <summary>
        /// This function will add the ads to each page depending as per the rule
        /// This will add the advertisement as per the rule to each news source separately.
        /// </summary>
        /// <param name="newsSources"></param>
        /// <param name="advertisements"></param>
        /// <returns></returns>
        List<NewsSource> AddAdvertisementsToNews(List<NewsSource> newsSources, List<Advertisement> advertisements, bool needConcatedResult);
    }
}
