﻿using NewsService.Data.Entity;
using System.Collections.Generic;

namespace NewsService.Data.AbstractClasses
{
    public abstract class NewsServiceBaseClass
    {
        public string Name { get; set; }
        public bool IsInternal { get; set; }

        public virtual List<NewsDetails> GetNewsFromSource(NewsSelectionCriteria newsSelectionCriteria)
        {
            //We can send the details from NewsSelectionCriteria as a input to API for filtering news.
            return new List<NewsDetails>();
        }
    }
}
