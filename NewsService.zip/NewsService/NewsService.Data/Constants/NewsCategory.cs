﻿namespace NewsService.Data.Constants
{
    //This should be configuarable from the database.
    public enum NewsCategoryEnum
    {
        Political,
        Finance,
        Sports,
        Travel,
        Advertisements,
        Business
    }
}
