﻿namespace NewsService.Data.Constants
{
    public enum NewsPriority
    {
        High,
        Medium,
        Low
    }
}
