﻿namespace NewsService.Data.Constants
{
    public static class NewsSources
    {
        public const string Google = "Google";
        public const string PTI = "PTI";
        public const string Internal1 = "Internal1";
        public const string All = "All";
    }
}
