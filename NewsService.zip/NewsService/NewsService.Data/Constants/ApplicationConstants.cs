﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NewsService.Data.Constants
{
    public static class ApplicationConstants
    {
        //This can be fetched from the configuration file or can be taken as input.
        public const int ADVERTISEMENT_COUNT_IN_SINGLE_PAGE = 2;
        public const int NEWS_PAGE_SIZE = 8;
        public const int CACHE_TIME_OUT = 15;
        public const int ABSOLUT_EXPRIRAION_TIMEOUT = 30;
        public const string CACHE_KEY_NEWS_SERVICES = "CacheKey_NewsServices";
    }
}
