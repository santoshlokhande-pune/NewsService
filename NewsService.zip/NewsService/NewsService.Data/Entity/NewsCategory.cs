﻿namespace NewsService.Data.Entity
{
    public class NewsCategory
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
}
