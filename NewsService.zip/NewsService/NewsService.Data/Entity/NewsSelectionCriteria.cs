﻿using NewsService.Data.Constants;
using System;
using System.Collections.Generic;
using System.Text;

namespace NewsService.Data.Entity
{
    public class NewsSelectionCriteria
    {
        public int LastXNews { get; set; }
        public int NewsFromLastXHours { get; set; }
        public NewsCategoryEnum NewsCategory { get; set; }
        public string Location { get; set; }

        public bool NeedConcatedResult { get; set; }
    }
}
