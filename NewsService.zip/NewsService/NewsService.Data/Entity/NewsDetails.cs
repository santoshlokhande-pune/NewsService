﻿using NewsService.Data.Constants;
using System;

namespace NewsService.Data.Entity
{
    public class NewsDetails
    {
        //Assuming we will get id as guid from news sources
        public Guid Id { get; set; }
        public string Category { get; set; }
        public NewsPriority Priority { get; set; }
        public string Title { get; set; }
        public string ShortDescription { get; set; }
        public string LongDescription { get; set; }
        public string Author { get; set; }
        public DateTime PublishDate { get; set; }
        public string Location { get; set; }
    }
}
