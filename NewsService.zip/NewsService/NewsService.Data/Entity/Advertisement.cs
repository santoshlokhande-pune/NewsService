﻿using System;

namespace NewsService.Data.Entity
{
    public class Advertisement
    {
        public Guid Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string ImageUrl { get; set; }
        public string TargetUrl { get; set; }
    }
}
