﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace NewsService.Data.Entity
{
    public class NewsSource
    {
        public NewsSource(string name, bool isInternal)
        {
            this.Name = name;
            this.IsInternal = isInternal;
        }

        public string Name { get; set; }
        public bool IsInternal { get; set; }

        public IEnumerable<NewsDetails> News { get; set; }

        /// <summary>
        /// This will hold the number of pages with news and addds in tupple
        /// </summary>
        public List<(int PageNumber, IEnumerable<NewsDetails> NewsDetails,IEnumerable<Advertisement> Advertisements)> NewsPages { get; set; }

        public IEnumerable<Advertisement> Advertisements { get; set; }

        public int HighPriorityNewsCount => News.Count(t => t.Priority == Constants.NewsPriority.High);
    }
}
